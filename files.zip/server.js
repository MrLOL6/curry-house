const express=require('express'),fs=require('fs'),crypto=require('crypto'),path=require('path');
const F=process.env.DATA_FILE||path.join(__dirname,'data.json');
const rnd=n=>Array.from(crypto.randomBytes(n),b=>'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[b%62]).join('');
const hp=(p,s)=>crypto.scryptSync(p,s,32).toString('hex');
const P=(n,d,p,v)=>({n,d,p,v:!!v});
const site={name:'Curry House',tag:'Cuisine indienne à Montreuil',hero:'Les saveurs de l’Inde, au cœur de Montreuil',about:'Curry, tandoori et naans cuits minute : une cuisine généreuse et parfumée, à savourer sur place ou à emporter.',heroImg:'',
phone1:'09 83 03 66 92',phone2:'07 63 42 41 10',whatsapp:'07 63 42 41 10',address:'72 rue Beaumarchais, 93100 Montreuil',hours:'Tous les jours\nDéjeuner : 12h00 – 14h30\nDîner : 18h30 – 23h00',services:['Déjeuner','Dîner'],
menu:[{name:'Entrées',items:[P('Crispy oignons','Bhaji d’oignons marinés aux épices, salade et sauce menthe','7,90 €'),P('Pois chiches chat masala','Poêlée de pois chiches, épices indiennes','8,50 €',1),P('Raïta','Yaourt concombre et épices','6,90 €',1)]},
{name:'Tandoori',items:[P('Agneau tikka','Morceaux d’agneau marinés cuits au tandoor','8,90 €')]},
{name:'Currys',items:[P('Poulet tikka jalfrezi','Sauce relevée aux poivrons et oignons','14,90 €'),P('Butter chicken tikka','Sauce crémeuse au beurre','14,90 €'),P('Shatkora tikka agneau','Sauce moyenne, citron vert et herbes fraîches','19,50 €')]},
{name:'Accompagnements',items:[P('Naan','Pain cuit au tandoor','3,00 €',1),P('Cheese naan','Naan farci au fromage','4,00 €',1),P('Riz pulao basmati','','4,00 €',1)]}],
mentions:'Éditeur : Curry House, 72 rue Beaumarchais, 93100 Montreuil. Tél. : 09 83 03 66 92.\nDirecteur de la publication : [à compléter]\nSIRET : [à compléter]\nHébergeur : [à compléter]',
privacy:'Les données saisies dans le formulaire de réservation (nom, téléphone, e-mail, demande particulière) servent uniquement à traiter votre réservation. Elles ne sont ni vendues ni cédées. Conservation : 12 mois maximum. Vous pouvez demander l’accès, la rectification ou la suppression de vos données en nous contactant par téléphone ou au restaurant.'};
let D=fs.existsSync(F)?JSON.parse(fs.readFileSync(F)):(()=>{const s=rnd(16);return{admin:process.env.ADMIN_PATH||'gestion-'+rnd(20),salt:s,hash:hp('AdminCurryHouse123!',s),draft:site,live:site,res:[]}})();
const save=()=>fs.writeFileSync(F,JSON.stringify(D));save();
const B='/'+D.admin,tok=new Map(),app=express();
app.use(express.json({limit:'15mb'}));
app.get('/api/site',(q,s)=>s.json(D.live));
const lim={};app.post('/api/reserve',(q,s)=>{const b=q.body||{},ip=q.ip,now=Date.now();lim[ip]=(lim[ip]||[]).filter(t=>now-t<6e5);
 if(lim[ip].length>=5)return s.status(429).json({e:'Trop de demandes, réessayez plus tard.'});
 const c=x=>String(x||'').trim().slice(0,300),r={id:rnd(10),at:now,name:c(b.name),phone:c(b.phone),email:c(b.email),note:c(b.note),date:c(b.date),service:c(b.service),n:+b.n,status:'new'};
 if(!r.name)return s.status(400).json({e:'Merci d’indiquer votre nom.'});
 if(!r.phone&&!r.email)return s.status(400).json({e:'Indiquez au moins un téléphone ou un e-mail.'});
 if(r.email&&!/^\S+@\S+\.\S+$/.test(r.email))return s.status(400).json({e:'E-mail invalide.'});
 if(!/^\d{4}-\d\d-\d\d$/.test(r.date)||r.date<new Date().toISOString().slice(0,10))return s.status(400).json({e:'Date invalide.'});
 if(!D.live.services.includes(r.service))return s.status(400).json({e:'Choisissez un service.'});
 if(!(r.n>=1&&r.n<=30))return s.status(400).json({e:'Nombre de personnes invalide.'});
 lim[ip].push(now);D.res.unshift(r);save();s.json({ok:1})});
app.get(B,(q,s)=>q.originalUrl.endsWith('/')?s.type('html').send(fs.readFileSync(path.join(__dirname,'public/admin.html'),'utf8').replace(/__B__/g,B)):s.redirect(B+'/'));
const A=express.Router();app.use(B,A);
A.post('/api/login',(q,s)=>setTimeout(()=>{const ok=crypto.timingSafeEqual(Buffer.from(hp(String(q.body.p||''),D.salt)),Buffer.from(D.hash));if(!ok)return s.status(401).json({e:'Mot de passe incorrect'});
 const t=rnd(40);tok.set(t,Date.now()+864e5);s.setHeader('Set-Cookie',`t=${t}; HttpOnly; SameSite=Strict; Path=${B}; Max-Age=86400`+(q.secure?'; Secure':''));s.json({ok:1})},500));
A.use('/api',(q,s,n)=>{const t=(q.headers.cookie||'').match(/t=(\w+)/)?.[1];if(!t||!(tok.get(t)>Date.now()))return s.status(401).json({e:'auth'});n()});
A.get('/api/state',(q,s)=>s.json({draft:D.draft,res:D.res,dirty:JSON.stringify(D.draft)!==JSON.stringify(D.live)}));
A.put('/api/draft',(q,s)=>{D.draft=q.body;save();s.json({ok:1})});
A.post('/api/publish',(q,s)=>{D.live=JSON.parse(JSON.stringify(D.draft));save();s.json({ok:1})});
A.post('/api/res/:id',(q,s)=>{const r=D.res.find(x=>x.id===q.params.id);if(!r)return s.sendStatus(404);r.status=q.body.status;r.reason=q.body.reason;save();s.json({ok:1})});
A.delete('/api/res/:id',(q,s)=>{D.res=D.res.filter(x=>x.id!==q.params.id);save();s.json({ok:1})});
A.post('/api/password',(q,s)=>{const{o,p}=q.body;if(hp(String(o),D.salt)!==D.hash)return s.status(400).json({e:'Ancien mot de passe incorrect'});
 if(String(p).length<10)return s.status(400).json({e:'10 caractères minimum'});D.salt=rnd(16);D.hash=hp(p,D.salt);tok.clear();save();s.json({ok:1})});
app.use(express.static(path.join(__dirname,'public')));
app.listen(process.env.PORT||3000,()=>console.log('Site : http://localhost:'+(process.env.PORT||3000)+'\nPanel : '+B+'/'));
